# Arcade Mouse Controller

**Board:** Pro Micro klon (ATmega32U4 / Binghe 3)

En arcade-controller med to knapper, en LED og et potentiometer. Knap 1 holder museknappen nede (til drag og markering), knap 2 autoklikker så længe du holder den inde, og potentiometeret styrer hvor hurtigt der autoklikkes. LED'en blinker ved hvert eneste klik.

---

## Hvad Kan Den?

- **Knap 1 (hold-klik)** — hold knappen = hold museknappen nede (til at trække, markere tekst osv.)
- **Knap 2 (autoclick)** — hold knappen = klik gentagne gange automatisk
- **Potentiometer** — drej for at justere autoclick-hastighed i realtid (2–33 klik/sek)
- **LED** — blinker kort ved hvert klik og autoclick, så du kan se hvad der sker
- **Plug and play** — computeren ser det som en rigtig mus, ingen drivere nødvendigt

---

## Hvad Skal Du Bruge?

| Del | Antal | Bemærkning |
|-----|-------|------------|
| Pro Micro (ATmega32U4) | 1 | 5V/16MHz eller 3.3V/8MHz klon |
| Arcade-knap med mikroswitch | 2 | Én til hold-klik, én til autoclick |
| 10kΩ potentiometer | 1 | Lineær type (B10K) er bedst |
| LED (valgfri farve) | 1 | Normal 3mm eller 5mm LED |
| 220Ω modstand | 1 | Beskytter LED'en |
| Ledninger | Lidt | Til at forbinde det hele |

---

## Sådan Forbinder Du Det Hele (Wiring)

![Forbindelsesdiagram](wiring-diagram.svg)

### Knap 1 — Hold-klik

| Knappens ben | Forbindes til |
|---|---|
| Ben 1 | Pro Micro **Pin 2** |
| Ben 2 | Pro Micro **GND** |

### Knap 2 — Autoclick

| Knappens ben | Forbindes til |
|---|---|
| Ben 1 | Pro Micro **Pin 3** |
| Ben 2 | Pro Micro **GND** |

Ingen ekstra modstande nødvendigt til knapperne — koden tænder interne pull-up modstande automatisk.

### LED — Klik-indikator

| LED-ben | Forbindes til |
|---|---|
| Langt ben (+) anode | Pro Micro **Pin 4** (gennem 220Ω modstand) |
| Kort ben (−) katode | Pro Micro **GND** |

Forbindelsen: **Pin 4 → 220Ω modstand → LED langt ben (+) → LED kort ben (−) → GND**

> **Hvis LED'en ikke lyser:** Prøv at vende den om. LED'er virker kun i én retning.

### Potentiometer — Hastighedskontrol

| Pot-ben | Forbindes til |
|---|---|
| Venstre ydre ben | Pro Micro **GND** |
| Midterste ben (wiper) | Pro Micro **A0** |
| Højre ydre ben | Pro Micro **VCC** |

> **Drejer den den forkerte vej?** Byt GND og VCC på de ydre ben.

---

## Opsætning af Arduino IDE

1. Tilføj SparkFun board-support URL under **File → Preferences → Additional Board Manager URLs:**
   ```
   https://raw.githubusercontent.com/sparkfun/Arduino_Boards/master/IDE_Board_Manager/package_sparkfun_index.json
   ```
2. Installer **SparkFun AVR Boards** via **Tools → Board → Boards Manager**
3. Vælg **SparkFun Pro Micro** og processor `ATmega32U4 (5V, 16MHz)`
4. Vælg den rigtige port under **Tools → Port**
5. Åbn `ArcadeMouseController.ino` og klik **Upload**

---

## Sådan Virker Koden

### Pin-opsætning

```cpp
const int buttonPin = 2;      // Knap 1: hold-klik
const int autoClickPin = 3;   // Knap 2: autoclick
const int ledPin = 4;         // LED: klik-indikator
const int potPin = A0;        // Potentiometer: hastighedskontrol
```

### Hastighedsgrænser

```cpp
const unsigned long AUTO_CLICK_MIN = 30;   // Hurtigst (ms mellem klik)
const unsigned long AUTO_CLICK_MAX = 500;  // Langsomst (ms mellem klik)
```

| Interval | Klik/sek |
|---|---|
| 30ms | ~33 klik/sek |
| 100ms | ~10 klik/sek |
| 250ms | ~4 klik/sek |
| 500ms | ~2 klik/sek |

### Knap 1: `Mouse.press()` og `Mouse.release()`

```cpp
if (stableState == LOW) {
  Mouse.press(MOUSE_LEFT);    // Hold museknappen nede
  blinkLed();
} else {
  Mouse.release(MOUSE_LEFT);  // Slip museknappen
}
```

Knap 1 bruger `Mouse.press()` når du trykker ned og `Mouse.release()` når du slipper. Det betyder at museknappen holdes nede præcis så længe du holder arcade-knappen — perfekt til at trække filer, markere tekst eller holde nede i spil.

### Knap 2: Autoclick med potentiometer

```cpp
if (autoClickStableState == LOW) {
  int potValue = analogRead(potPin);
  unsigned long autoClickInterval = map(potValue, 0, 1023, AUTO_CLICK_MIN, AUTO_CLICK_MAX);

  if ((millis() - lastAutoClick) >= autoClickInterval) {
    Mouse.click(MOUSE_LEFT);
    blinkLed();
    lastAutoClick = millis();
  }
}
```

Så længe knap 2 holdes nede, læser koden potentiometeret og klikker med den hastighed det er sat til. Potentiometeret aflæses hele tiden, så du kan justere hastigheden mens den kører.

### LED-blink funktionen

```cpp
void blinkLed() {
  digitalWrite(ledPin, HIGH);
  delayMicroseconds(500);
  digitalWrite(ledPin, LOW);
}
```

Et ultrakort blink på 0.5 millisekund — hurtigt nok til at øjet ser et glimt, men kort nok til ikke at bremse koden. Ved hurtig autoclick flimrer LED'en som en stroboskop, og ved langsom autoclick ser du tydelige individuelle blink.

### Debouncing

```cpp
const unsigned long debounceDelay = 30;
```

Begge knapper bruger den samme debounce-tid på 30ms. Når kontakterne i en mikroswitch rammer hinanden, ryster de kort — debounce-logikken ignorerer rystelserne og sikrer at hvert tryk kun tæller én gang.

### Sikkerhed ved opstart

```cpp
Mouse.release(MOUSE_LEFT);
Mouse.begin();
```

`Mouse.release()` køres før `Mouse.begin()` som en sikkerhed. Hvis boardet blev taget ud af strømmen mens museknappen var holdt nede, sørger denne linje for at den slippes ved genstart.

---

## Overblik

```
KNAP 1 (Pin 2)                    KNAP 2 (Pin 3)
  │                                  │
  ├─ Tryk ned → Mouse.press()        ├─ Hold nede → Autoclick starter
  │              LED blinker          │               LED blinker per klik
  │                                   │               Pot styrer hastighed
  └─ Slip → Mouse.release()          └─ Slip → Autoclick stopper
```

---

## Pin-oversigt

| Del | Pin | Funktion |
|-----|-----|----------|
| Knap 1 | Pin 2 | Hold = hold museklik |
| Knap 2 | Pin 3 | Hold = autoclick |
| LED | Pin 4 | Blinker ved hvert klik |
| Potentiometer | A0 | Styrer autoclick-hastighed |

---

## Ting Du Kan Ændre

| Hvad vil du ændre? | Variabel | Standard |
|---------------------|----------|----------|
| Hurtigste autoclick | `AUTO_CLICK_MIN` | 30ms (~33 klik/sek) |
| Langsomste autoclick | `AUTO_CLICK_MAX` | 500ms (~2 klik/sek) |
| Knap 1 pin | `buttonPin` | 2 |
| Knap 2 pin | `autoClickPin` | 3 |
| LED pin | `ledPin` | 4 |
| Potentiometer pin | `potPin` | A0 |
| Debounce-tid | `debounceDelay` | 30ms |

---

## Fejlfinding

| Problem | Løsning |
|---------|---------|
| Knap 1 klikker i stedet for at holde | Tjek at du bruger `Mouse.press()` / `Mouse.release()` og ikke `Mouse.click()` |
| Dobbelt-klik ved enkelt tryk | Skru `debounceDelay` op til 40–50 |
| Autoclick for hurtig/langsom | Ændr `AUTO_CLICK_MIN` og `AUTO_CLICK_MAX` |
| Potentiometeret drejer forkert | Byt GND og VCC på de ydre ben |
| LED lyser ikke | Tjek polaritet — langt ben (+) mod modstanden, kort ben (−) mod GND |
| Musen sidder fast i "holdt nede" | Tag USB ud og sæt i igen — `Mouse.release()` i setup løser det |
| Arduino IDE finder ikke boardet | Tjek processor-indstilling (5V/16MHz) |
| "Mouse was not declared" fejl | Tjek at SparkFun Pro Micro er valgt som board |

---

## Næste Skridt

- **Tilføj højreklik** med en tredje knap på `MOUSE_RIGHT`
- **Tilføj tastatur-tryk** med `Keyboard.h` biblioteket
- **Byg en kasse** til det hele — 3D-print eller træ
- **Tilføj en joystick** for at styre musemarkøren

God fornøjelse med byggeriet! 🕹️
