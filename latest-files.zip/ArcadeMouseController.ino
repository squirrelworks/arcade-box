#include <Mouse.h>

// ============================================================
// ARCADE MOUSE CONTROLLER
// Knap 1 (Pin 2): Hold = hold museklik (drag, markér tekst)
// Knap 2 (Pin 3): Hold = autoclick med justerbar hastighed
// Potentiometer (A0): Styr autoclick-hastighed i realtid
// LED (Pin 4): Blinker ved hvert klik og autoclick
// Board: Pro Micro (ATmega32U4)
// ============================================================

// --- Knap 1: Hold museklik ---
const int buttonPin = 2;
bool lastButtonState = HIGH;
bool stableState = HIGH;
unsigned long lastDebounceTime = 0;

// --- Knap 2: Autoclick ---
const int autoClickPin = 3;
bool autoClickLastState = HIGH;
bool autoClickStableState = HIGH;
unsigned long autoClickDebounceTime = 0;
unsigned long lastAutoClick = 0;

// --- Potentiometer: Hastighedskontrol ---
const int potPin = A0;
const unsigned long AUTO_CLICK_MIN = 30;   // Hurtigst (ms mellem klik)
const unsigned long AUTO_CLICK_MAX = 500;  // Langsomst (ms mellem klik)

// --- LED: Klik-indikator ---
const int ledPin = 4;

// --- Debounce (delt af begge knapper) ---
const unsigned long debounceDelay = 30;

// Kort blink — synligt men bremser ikke koden
void blinkLed() {
  digitalWrite(ledPin, HIGH);
  delayMicroseconds(500);
  digitalWrite(ledPin, LOW);
}

void setup() {
  Serial.begin(9600);
  Serial.println("started");

  pinMode(buttonPin, INPUT_PULLUP);
  pinMode(autoClickPin, INPUT_PULLUP);
  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, LOW);

  Mouse.release(MOUSE_LEFT);  // Sikkerhed: slip mus ved opstart
  Mouse.begin();
}

void loop() {

  // ===== KNAP 1: Hold museklik =====
  bool reading = digitalRead(buttonPin);

  if (reading != lastButtonState) {
    lastDebounceTime = millis();
  }

  if ((millis() - lastDebounceTime) > debounceDelay) {
    if (reading != stableState) {
      stableState = reading;

      if (stableState == LOW) {
        Serial.println("press");
        Mouse.press(MOUSE_LEFT);
        blinkLed();
      } else {
        Serial.println("release");
        Mouse.release(MOUSE_LEFT);
      }
    }
  }
  lastButtonState = reading;

  // ===== KNAP 2: Autoclick =====
  bool autoReading = digitalRead(autoClickPin);

  if (autoReading != autoClickLastState) {
    autoClickDebounceTime = millis();
  }

  if ((millis() - autoClickDebounceTime) > debounceDelay) {
    if (autoReading != autoClickStableState) {
      autoClickStableState = autoReading;
    }
  }
  autoClickLastState = autoReading;

  // Klik gentagne gange så længe knap 2 holdes nede
  if (autoClickStableState == LOW) {
    int potValue = analogRead(potPin);
    unsigned long autoClickInterval = map(
      potValue,
      0, 1023,
      AUTO_CLICK_MIN, AUTO_CLICK_MAX
    );

    if ((millis() - lastAutoClick) >= autoClickInterval) {
      Serial.println("autoclick");
      Mouse.click(MOUSE_LEFT);
      blinkLed();
      lastAutoClick = millis();
    }
  }
}
